<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Session;

class HomeController extends Controller
{
    public function showHome()
    {
        $total_students = DB::select("SELECT COUNT(student_id) AS total_students FROM students");

        return view('welcome', compact('total_students'));
    }
}