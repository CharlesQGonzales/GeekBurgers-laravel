<!DOCTYPE html>
<html lang="en">
<head>
    <title>Home</title>
</head>
<body>
    @if(Session::has('success'))
        <p style="color:green">{{Session::get('success')}}</p>
    @endif
    @if(Session::has('fail'))
        <p style="color:red">{{Session::get('fail')}}</p>
    @endif
    <h1>Welcome to ISCP</h1>
    @foreach($total_students as $total_student)
    <p> {{$total_student -> total_students}} students enrolled. </p>
    @endforeach
    <p> The best university in South East Asia. </p>
    <p> Raising young minds to be responsible leaders. </p>
    <p> Enroll now! </p>
    <a href="/student_finder">Go to student finder!</a>
    <h1>Login</h1>
    <form action="/" method="POST">
        @csrf
        <label>Email:</label>
        <input type="email" name="email"></input><br>
        <label>Password:</label>
        <input type="password" name="pw"></input><br>
        <button type="submit">Login</button>
    </form>
</body>
</html>